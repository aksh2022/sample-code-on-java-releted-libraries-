package AbcdPack;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Abcd {

	public static void main(String[] args) {
	
		
		DocumentBuilderFactory factory  = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse("People.xml");
			NodeList PersonList  = doc.getElementsByTagName("person");
			for(int i=0;i< PersonList.getLength();i++) {
				Node person = PersonList.item(i);
				if(person.getNodeType() == person.ELEMENT_NODE) {
					Element element = (Element) person;
					String id = element.getAttribute("id");
					System.out.println("person ID"+" "+id);
					NodeList list = element.getChildNodes();
					
					for(int j=0;j<list.getLength();j++) {
						
						Node n = list.item(j);
						if(n.getNodeType() == n.ELEMENT_NODE) {
							Element ele = (Element) n;
							
							System.out.println(ele.getTagName()+" : "+ele.getTextContent());
						}
					}
					
				}
				
				
			}
			
			
			
		} catch (ParserConfigurationException e) {
			
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
