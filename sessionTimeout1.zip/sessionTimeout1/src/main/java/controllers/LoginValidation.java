 package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginValidation
 */
@WebServlet("/LoginValidation")
public class LoginValidation extends HttpServlet {
		

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("dfdahfdafadfdfdsfsfsdf");
	String name  = request.getParameter("name");
	String password = request.getParameter("password");
	
	ServletContext con = getServletContext();
	
	System.out.println(name+" "+password);
	System.out.println(con.getInitParameter("name"));
	System.out.println(con.getInitParameter("password"));
PrintWriter write = response.getWriter();
write.print(name+" "+password);
	if(name.equals(con.getInitParameter("name")) && password.equals(con.getInitParameter("password"))){
		System.out.println("under if");
		RequestDispatcher req = request.getRequestDispatcher("/home.jsp");
		req.forward(request, response);
	}else {
		RequestDispatcher req = request.getRequestDispatcher("/login.jsp");
		request.setAttribute("error","Incorrect username or password ");
		req.forward(request, response);
		
	}
	
	
		
		
	}

}
